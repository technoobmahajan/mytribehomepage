import React from 'react';

const citiesLinks = [
  'Balloon Decor in Delhi',
  'Balloon Decor in Mumbai',
  'Balloon Decor in Bangalore',
  'Balloon Decor in Pune',
  'Magician in Delhi',
  'Magician in Mumbai',
  'Magician in Bangalore',
  'Magician in Pune',
  'Wedding Photography in Delhi',
  'Wedding Photography in Mumbai',
];

const categoryLinks = [
  'Birthday Party Planners',
  'Wedding Planners',
  'Corporate Event Management',
  'DJ Services',
  'Catering Services',
  'Makeup Artists',
  'Mehendi Artists',
  'Bridal Makeup',
  'Event Decorators',
  'Sound System Rental',
];

const servicesLinks = [
  'Photography Services',
  'Videography Services',
  'DJ in Delhi',
  'DJ in Mumbai',
  'Catering in Bangalore',
  'Catering in Pune',
  'Makeup Artist in Delhi',
  'Makeup Artist in Mumbai',
  'Photographer in Bangalore',
  'Photographer in Pune',
];

/* FIXED: Replaced SEO links with actual Company links */
const companyLinks = [
  'About Us',
  'Careers',
  'Blog',
  'Press',
  'Contact Support',
];

export function Footer() {
  return (
    <footer 
      className="pt-16 pb-8 bg-[#F7F7F7] border-t border-gray-200"
      /* FORCE THE FONT HERE directly via style style */
      style={{ fontFamily: "'DM Sans', sans-serif" }}
    >
      
      {/* Load the font inside the component to be safe */}
      <style>
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;500;700&display=swap');
      </style>

      <div className="max-w-7xl mx-auto px-8">
        
        {/* Top Section: Logo & tagline */}
        <div className="mb-12">
          <h3 className="text-2xl mb-4 text-[#222222] font-bold tracking-tight">
            MyTribe
          </h3>
          <p className="text-gray-500 max-w-md text-sm leading-relaxed">
            Your trusted marketplace for premium service professionals. Verified experts, instant quotes, guaranteed quality.
          </p>
        </div>

        {/* Links Grid - Fixed Mobile Responsiveness */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12 mb-16">
          
          {/* Column 1: BY CITY */}
          <div>
            <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-6">
              By City
            </h4>
            <div className="flex flex-col gap-3">
              {citiesLinks.map((link, index) => (
                <a
                  key={index}
                  href="#"
                  className="text-sm text-gray-600 hover:text-[#6F42C1] hover:underline transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>

          {/* Column 2: BY CATEGORY */}
          <div>
            <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-6">
              By Category
            </h4>
            <div className="flex flex-col gap-3">
              {categoryLinks.map((link, index) => (
                <a
                  key={index}
                  href="#"
                  className="text-sm text-gray-600 hover:text-[#6F42C1] hover:underline transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>

          {/* Column 3: POPULAR SERVICES */}
          <div>
            <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-6">
              Popular Services
            </h4>
            <div className="flex flex-col gap-3">
              {servicesLinks.map((link, index) => (
                <a
                  key={index}
                  href="#"
                  className="text-sm text-gray-600 hover:text-[#6F42C1] hover:underline transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>

          {/* Column 4: COMPANY (Fixed Content) */}
          <div>
            <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-6">
              Company
            </h4>
            <div className="flex flex-col gap-3">
              {companyLinks.map((link, index) => (
                <a
                  key={index}
                  href="#"
                  className="text-sm text-gray-600 hover:text-[#6F42C1] hover:underline transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-500">
          <p>&copy; 2025 MyTribe. All rights reserved.</p>
          <div className="flex gap-6 font-medium">
            <a href="#" className="hover:text-gray-900 transition-colors">Privacy</a>
            <a href="#" className="hover:text-gray-900 transition-colors">Terms</a>
            <a href="#" className="hover:text-gray-900 transition-colors">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}