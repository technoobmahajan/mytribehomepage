import React, { useState, useEffect, useRef } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const steps = [
  {
    number: '01',
    title: 'Tell us the requirement',
    description: 'Instant matching with verified professionals. Our system connects you with experts who perfectly match your needs in seconds.',
    image: 'https://images.unsplash.com/photo-1680490958064-14ed3acf3498?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB3ZWRkaW5nJTIwY2VyZW1vbnl8ZW58MXx8fHwxNzY2OTg4MTcxfDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    number: '02',
    title: 'Get Instant Quotes',
    description: 'Compare accurate quotes instantly. See transparent pricing, detailed breakdowns, and real customer reviews all in one place.',
    image: 'https://images.unsplash.com/photo-1567199955211-2648518a7730?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaG9uZSUyMG1vY2t1cCUyMHF1b3RlJTIwcHJpY2V8ZW58MXx8fHwxNzY2OTkwMjA1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    number: '03',
    title: 'Enjoy the service',
    description: 'Relax while verified professionals deliver exceptional service. Fast booking, reliable execution, and quality guaranteed every time.',
    image: 'https://images.unsplash.com/photo-1647014726655-8541879fdc28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBob21lJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzY2OTkwMjA1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
];

export function HowItWorksSection() {
  const [activeStep, setActiveStep] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);
  const stepRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current || window.innerWidth < 768) return; 

      const windowHeight = window.innerHeight;

      stepRefs.current.forEach((ref, index) => {
        if (ref) {
          const stepTop = ref.getBoundingClientRect().top;
          const stepMiddle = stepTop + ref.offsetHeight / 2;
          
          if (stepMiddle < windowHeight / 2 + 100 && stepMiddle > 0) {
            setActiveStep(index);
          }
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section ref={sectionRef} className="py-16 md:py-24 px-6 md:px-8 bg-white">
      {/* FORCE FONT IMPORT */}
      <style>
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;500;700&display=swap');
      </style>

      {/* Main Container - Applied Font Globally to Section to fix the Serif issue */}
      <div className="max-w-7xl mx-auto" style={{ fontFamily: "'DM Sans', sans-serif" }}>
        
        <h2 className="text-3xl md:text-4xl mb-12 md:mb-24 text-center text-[#222222] font-bold tracking-tight">
          How It Works
        </h2>

        {/* --- DESKTOP LAYOUT (Unchanged) --- */}
        <div className="hidden md:grid grid-cols-2 gap-24 items-start">
          <div className="relative space-y-48 py-10">
            <div className="absolute left-[27px] top-10 bottom-40 w-[2px] bg-gray-100"></div>
            {steps.map((step, index) => (
              <div
                key={step.number}
                ref={(el) => (stepRefs.current[index] = el)}
                className="transition-all duration-500 relative pl-20"
                style={{
                  opacity: activeStep === index ? 1 : 0.2,
                }}
              >
                <div 
                  className="absolute left-0 top-0 flex items-center justify-center w-14 h-14 rounded-full bg-white border-4 border-white z-10"
                  style={{
                    boxShadow: activeStep === index ? '0 4px 20px rgba(111, 66, 193, 0.15)' : 'none'
                  }}
                >
                  <span className="text-xl font-bold text-[#6F42C1]">{step.number}</span>
                </div>
                <h3 className="text-3xl mb-4 text-[#222222] font-bold tracking-tight">{step.title}</h3>
                <p className="text-[#717171] text-lg leading-relaxed font-normal max-w-md">{step.description}</p>
              </div>
            ))}
          </div>
          <div className="relative h-full">
            <div className="sticky top-32">
              <div 
                className="overflow-hidden aspect-[4/5] bg-gray-50 transition-all duration-500" 
                style={{ 
                  borderRadius: '32px', 
                  boxShadow: '0 20px 40px rgba(0,0,0,0.08)'
                }}
              >
                <ImageWithFallback
                  src={steps[activeStep].image}
                  alt={steps[activeStep].title}
                  className="w-full h-full object-cover transition-opacity duration-700 ease-in-out"
                />
              </div>
            </div>
          </div>
        </div>

        {/* --- MOBILE LAYOUT (Fixed: Cards Restored) --- */}
        <div className="md:hidden space-y-8">
          {steps.map((step, index) => (
            <div
              key={step.number}
              className="bg-white overflow-hidden"
              // Adding the Card look back: Border Radius + Soft Shadow + Border
              style={{
                borderRadius: '20px',
                border: '1px solid #F3F4F6', // Very light border
                boxShadow: '0 8px 24px rgba(0,0,0,0.06)' // Soft float shadow
              }}
            >
              {/* Image Section */}
              <div className="aspect-video w-full bg-gray-100 relative">
                <ImageWithFallback
                  src={step.image}
                  alt={step.title}
                  className="w-full h-full object-cover"
                />
                {/* Step Badge - Overlay on Image now for better style */}
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full shadow-sm">
                  <span className="text-[#6F42C1] text-xs font-bold tracking-wide">
                    STEP {step.number}
                  </span>
                </div>
              </div>

              {/* Text Content */}
              <div className="p-6">
                <h3 className="text-xl mb-2 text-[#222222] font-bold">
                  {step.title}
                </h3>
                <p className="text-[#717171] text-sm leading-relaxed font-normal">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}