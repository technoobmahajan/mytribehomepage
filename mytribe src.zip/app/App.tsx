import React from 'react';
import { HeroSection } from './components/HeroSection';
import { RealUseCasesCarousel } from './components/RealUseCasesCarousel';
import { TrustSection } from './components/TrustSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <HeroSection />
      <RealUseCasesCarousel />
      <TrustSection />
      <HowItWorksSection />
      <FAQSection />
      <Footer />
    </div>
  );
}