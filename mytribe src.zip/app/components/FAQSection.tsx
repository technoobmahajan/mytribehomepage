import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';

const faqs = [
  {
    question: 'How does Mytribe understand my exact requirement?',
    answer: 'Our AI analyzes your description, preferences, and location to match you with specialists who fit your specific needs—considering style, budget, and timing.',
  },
  {
    question: 'How does Mytribe save my time?',
    answer: 'Get instant quotes from multiple verified providers in one place. Compare pricing, reviews, and availability without endless calls or emails.',
  },
  {
    question: 'How does Mytribe ensure service quality?',
    answer: 'Every provider undergoes rigorous verification: credential checks, work portfolio review, and customer feedback analysis. Only the top 10% are certified.',
  },
];

export function FAQSection() {
  return (
    <section className="py-20 px-8 bg-white">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-2xl mb-12 text-center text-[#111111]" style={{ fontWeight: 700 }}>
          Frequently Asked Questions
        </h2>

        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="bg-white px-6 border border-[#E5E5E5]"
              style={{ 
                borderRadius: '20px',
                boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.08), 0px 12px 24px rgba(0, 0, 0, 0.04)'
              }}
            >
              <AccordionTrigger className="text-left py-6 hover:no-underline">
                <span className="text-lg text-[#111111]" style={{ fontWeight: 700 }}>{faq.question}</span>
              </AccordionTrigger>
              <AccordionContent className="text-[#717171] pb-6 leading-relaxed" style={{ fontWeight: 400 }}>
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}