import React, { useState, useEffect } from 'react';
import { 
  Search, ChevronDown, User, ChevronLeft, ChevronRight, 
  MapPin, Sparkles, Dumbbell, PartyPopper, Image as ImageIcon, ArrowRight 
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

// --- DATA & CONFIG ---

const categories = [
  { id: 'fitness', label: 'Fitness', icon: Dumbbell },
  { id: 'parties', label: 'Parties', icon: PartyPopper },
  { id: 'beauty', label: 'Beauty', icon: Sparkles },
];

const subCategories: Record<string, string[]> = {
  fitness: ['Personal Trainers', 'Yoga Instructors', 'Dieticians'],
  parties: ['Party Decorators', 'Entertainers', 'Event Photographers'],
  beauty: ['Makeup Artists', 'Hair Stylists', 'Fashion Stylists'],
};

// Updated Data with Price Ranges & Cleaned Fields
const providersByCategory: Record<string, any[]> = {
  'Personal Trainers': [
    { 
      id: 1, 
      name: 'Rajesh Kumar', 
      location: 'Koramangala, Bengaluru',
      blurb: '7+ years exp, Gold Medalist',
      price: '1,500-2,000', 
      image: 'https://images.unsplash.com/photo-1734873477108-6837b02f2b9d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJzb25hbCUyMHRyYWluZXIlMjBmaXRuZXNzJTIwaW5kaWFufGVufDF8fHx8MTc2Njk5MjA1NXww&ixlib=rb-4.1.0&q=80&w=1080' 
    },
    { 
      id: 2, 
      name: 'Priya Sharma', 
      location: 'Indiranagar, Bengaluru',
      blurb: 'Certified Nutritionist, 50+ transformations',
      price: '1,200-1,800', 
      image: 'https://images.unsplash.com/photo-1758797315487-b3b225dff7d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b2dhJTIwaW5zdHJ1Y3RvciUyMGluZGlhfGVufDF8fHx8MTc2Njk5MjA1NXww&ixlib=rb-4.1.0&q=80&w=1080' 
    },
    { 
      id: 3, 
      name: 'Amit Patel', 
      location: 'HSR Layout, Bengaluru',
      blurb: 'Ex-Army Trainer, High Intensity Specialist',
      price: '1,800-2,500', 
      image: 'https://images.unsplash.com/photo-1741156229623-da94e6d7977d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxneW0lMjB0cmFpbmVyJTIwd29ya291dHxlbnwxfHx8fDE3NjY5OTIwNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080' 
    },
  ],
  'Yoga Instructors': [
    { id: 4, name: 'Anjali Desai', location: 'Whitefield, Bengaluru', blurb: '500hrs RYT Certified, Mindfulness Coach', price: '1,000-1,500', image: 'https://images.unsplash.com/photo-1667890786022-83bca6c4f4c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b2dhJTIwaW5zdHJ1Y3RvciUyMG1lZGl0YXRpb258ZW58MXx8fHwxNzY2OTk0ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 5, name: 'Vikram Singh', location: 'Jayanagar, Bengaluru', blurb: '10yrs exp, Ashtanga specialist', price: '1,100-1,600', image: 'https://images.unsplash.com/photo-1758797315487-b3b225dff7d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b2dhJTIwaW5zdHJ1Y3RvciUyMGluZGlhfGVufDF8fHx8MTc2Njk5MjA1NXww&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 6, name: 'Meera Iyer', location: 'Malleswaram, Bengaluru', blurb: 'Holistic Wellness Coach', price: '900-1,200', image: 'https://images.unsplash.com/photo-1667890786022-83bca6c4f4c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b2dhJTIwaW5zdHJ1Y3RvciUyMG1lZGl0YXRpb258ZW58MXx8fHwxNzY2OTk0ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080' },
  ],
  'Dieticians': [
    { id: 7, name: 'Dr. Sneha Reddy', location: 'JP Nagar, Bengaluru', blurb: 'PhD in Nutrition, Diabetes Reversal', price: '1,500-2,500', image: 'https://images.unsplash.com/photo-1577235857317-9aa8f577a3a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXRyaXRpb25pc3QlMjBkaWV0aWNpYW58ZW58MXx8fHwxNzY2OTk0ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 8, name: 'Rohit Mehta', location: 'Banashankari, Bengaluru', blurb: 'Certified Sports Nutritionist', price: '1,300-2,000', image: 'https://images.unsplash.com/photo-1577235857317-9aa8f577a3a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXRyaXRpb25pc3QlMjBkaWV0aWNpYW58ZW58MXx8fHwxNzY2OTk0ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 9, name: 'Kavita Nair', location: 'Hebbal, Bengaluru', blurb: 'PCOS & Gut Health Expert', price: '1,200-1,800', image: 'https://images.unsplash.com/photo-1577235857317-9aa8f577a3a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXRyaXRpb25pc3QlMjBkaWV0aWNpYW58ZW58MXx8fHwxNzY2OTk0ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080' },
  ],
  'Party Decorators': [
    { id: 10, name: 'Festive Creations', location: 'Indiranagar, Bengaluru', blurb: '1500+ Events, Corporate Specialist', price: '5,000-15,000', image: 'https://images.unsplash.com/photo-1762053275420-bf4653ea2612?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJ0eSUyMGRlY29yYXRvciUyMGJhbGxvb25zfGVufDF8fHx8MTc2Njk5NDg0MHww&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 11, name: 'Dream Decor Studio', location: 'Koramangala, Bengaluru', blurb: 'Themes like Cocomelon, Avengers', price: '6,500-20,000', image: 'https://images.unsplash.com/photo-1762053275420-bf4653ea2612?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJ0eSUyMGRlY29yYXRvciUyMGJhbGxvb25zfGVufDF8fHx8MTc2Njk5NDg0MHww&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 12, name: 'Elite Events Decor', location: 'Whitefield, Bengaluru', blurb: 'Luxury Weddings & Galas', price: '8,000-50,000', image: 'https://images.unsplash.com/photo-1762053275420-bf4653ea2612?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJ0eSUyMGRlY29yYXRvciUyMGJhbGxvb25zfGVufDF8fHx8MTc2Njk5NDg0MHww&ixlib=rb-4.1.0&q=80&w=1080' },
  ],
  'Entertainers': [
    { id: 13, name: 'Magic Moments', location: 'HSR Layout, Bengaluru', blurb: 'Interactive Shows, 10yrs exp', price: '3,500-8,000', image: 'https://images.unsplash.com/photo-1615864691103-ba5913c2ac48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWdpY2lhbiUyMGVudGVydGFpbmVyfGVufDF8fHx8MTc2Njk5NDg0MXww&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 14, name: 'The Fun Factory', location: 'Jayanagar, Bengaluru', blurb: 'Puppetry, Ventriloquism', price: '4,000-9,000', image: 'https://images.unsplash.com/photo-1615864691103-ba5913c2ac48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWdpY2lhbiUyMGVudGVydGFpbmVyfGVufDF8fHx8MTc2Njk5NDg0MXww&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 15, name: 'DJ Vibes', location: 'Koramangala, Bengaluru', blurb: 'Bollywood, EDM, Hip-Hop', price: '5,500-15,000', image: 'https://images.unsplash.com/photo-1615864691103-ba5913c2ac48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWdpY2lhbiUyMGVudGVydGFpbmVyfGVufDF8fHx8MTc2Njk5NDg0MXww&ixlib=rb-4.1.0&q=80&w=1080' },
  ],
  'Event Photographers': [
    { id: 16, name: 'FramePerfect Studio', location: 'MG Road, Bengaluru', blurb: 'Candid Moments, Same Day Edit', price: '4,500-12,000', image: 'https://images.unsplash.com/photo-1711473726143-b26145e55772?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaG90b2dyYXBoZXIlMjBjYW1lcmF8ZW58MXx8fHwxNzY2OTM4MTc4fDA&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 17, name: 'Candid Clicks', location: 'Indiranagar, Bengaluru', blurb: 'Wedding & Engagement Specialist', price: '5,000-25,000', image: 'https://images.unsplash.com/photo-1711473726143-b26145e55772?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaG90b2dyYXBoZXIlMjBjYW1lcmF8ZW58MXx8fHwxNzY2OTM4MTc4fDA&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 18, name: 'Lens & Light Pro', location: 'Whitefield, Bengaluru', blurb: 'Cinematic Video & Drone', price: '7,000-30,000', image: 'https://images.unsplash.com/photo-1711473726143-b26145e55772?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaG90b2dyYXBoZXIlMjBjYW1lcmF8ZW58MXx8fHwxNzY2OTM4MTc4fDA&ixlib=rb-4.1.0&q=80&w=1080' },
  ],
  'Makeup Artists': [
    { id: 19, name: 'Glam Studio', location: 'Koramangala, Bengaluru', blurb: 'MAC & Huda Beauty Products', price: '3,500-8,000', image: 'https://images.unsplash.com/photo-1698181842119-a5283dea1440?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWtldXAlMjBhcnRpc3QlMjBiZWF1dHl8ZW58MXx8fHwxNzY2OTE3NzA5fDA&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 20, name: 'Beauty By Priya', location: 'Jayanagar, Bengaluru', blurb: 'Natural Finish Specialist', price: '4,000-10,000', image: 'https://images.unsplash.com/photo-1698181842119-a5283dea1440?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWtldXAlMjBhcnRpc3QlMjBiZWF1dHl8ZW58MXx8fHwxNzY2OTE3NzA5fDA&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 21, name: 'Elite Makeup Artists', location: 'UB City, Bengaluru', blurb: 'Celebrity Style Makeovers', price: '6,000-25,000', image: 'https://images.unsplash.com/photo-1698181842119-a5283dea1440?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWtldXAlMjBhcnRpc3QlMjBiZWF1dHl8ZW58MXx8fHwxNzY2OTE3NzA5fDA&ixlib=rb-4.1.0&q=80&w=1080' },
  ],
  'Hair Stylists': [
    { id: 22, name: 'Locks & Curls Salon', location: 'Indiranagar, Bengaluru', blurb: 'Keratin & Botox Experts', price: '2,500-6,000', image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYWlyJTIwc3R5bGlzdCUyMHNhbG9ufGVufDF8fHx8MTc2Njk3Njc3Mnww&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 23, name: 'The Hair Studio', location: 'Whitefield, Bengaluru', blurb: 'Intricate Bridal Updos', price: '3,000-8,000', image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYWlyJTIwc3R5bGlzdCUyMHNhbG9ufGVufDF8fHx8MTc2Njk3Njc3Mnww&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 24, name: 'Tresses by Neha', location: 'Koramangala, Bengaluru', blurb: 'Balayage & Ombre Specialist', price: '3,500-9,000', image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYWlyJTIwc3R5bGlzdCUyMHNhbG9ufGVufDF8fHx8MTc2Njk3Njc3Mnww&ixlib=rb-4.1.0&q=80&w=1080' },
  ],
  'Fashion Stylists': [
    { id: 25, name: 'Style Statement', location: 'MG Road, Bengaluru', blurb: 'Wardrobe Revamp & Shopping', price: '4,000-10,000', image: 'https://images.unsplash.com/photo-1568251188392-ae32f898cb3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwc3R5bGlzdCUyMGRlc2lnbmVyfGVufDF8fHx8MTc2Njk5NDg0Mnww&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 26, name: 'Chic Consulting', location: 'Indiranagar, Bengaluru', blurb: 'Red Carpet Ready Looks', price: '3,500-8,000', image: 'https://images.unsplash.com/photo-1568251188392-ae32f898cb3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwc3R5bGlzdCUyMGRlc2lnbmVyfGVufDF8fHx8MTc2Njk5NDg0Mnww&ixlib=rb-4.1.0&q=80&w=1080' },
    { id: 27, name: 'Vogue Stylists', location: 'Koramangala, Bengaluru', blurb: 'Complete Image Makeover', price: '5,000-15,000', image: 'https://images.unsplash.com/photo-1568251188392-ae32f898cb3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwc3R5bGlzdCUyMGRlc2lnbmVyfGVufDF8fHx8MTc2Njk5NDg0Mnww&ixlib=rb-4.1.0&q=80&w=1080' },
  ],
};

export function HeroSection() {
  const [currentCategoryIndex, setCurrentCategoryIndex] = useState(0); 
  const [selectedSubCategory, setSelectedSubCategory] = useState<string | null>('Personal Trainers'); 
  const activeCategory = categories[currentCategoryIndex];

  /* --- LOGIC: Typewriter Effect for Search Bar --- */
  const [placeholderText, setPlaceholderText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [loopNum, setLoopNum] = useState(0);
  const [typingSpeed, setTypingSpeed] = useState(100);

  const prefix = "Search for ";
  const services = [
    "balcony decorators",
    "birthday magicians",
    "maternity photographers",
    "personal trainers",
    "the best experts"
  ];

  useEffect(() => {
    const handleTyping = () => {
      const i = loopNum % services.length;
      const fullText = prefix + services[i];

      setPlaceholderText(
        isDeleting 
          ? fullText.substring(0, placeholderText.length - 1) 
          : fullText.substring(0, placeholderText.length + 1)
      );

      setTypingSpeed(isDeleting ? 40 : 80);

      if (!isDeleting && placeholderText === fullText) {
        setTimeout(() => setIsDeleting(true), 1500); 
      } 
      else if (isDeleting && placeholderText === prefix) {
        setIsDeleting(false);
        setLoopNum(loopNum + 1);
      }
    };

    const timer = setTimeout(handleTyping, typingSpeed);
    return () => clearTimeout(timer);
  }, [placeholderText, isDeleting, loopNum, typingSpeed]);

  const handlePrev = () => {
    setCurrentCategoryIndex((prev) => (prev === 0 ? categories.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentCategoryIndex((prev) => (prev === categories.length - 1 ? 0 : prev + 1));
  };

  const handleCategoryClick = (index: number) => {
    setCurrentCategoryIndex(index);
    setSelectedSubCategory(null); 
  };

  const handleSubCategoryClick = (sub: string) => {
    setSelectedSubCategory(selectedSubCategory === sub ? null : sub);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* 1. CUSTOM STYLES for Animations */}
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,500;700&display=swap');
          
          /* LOGO ANIMATION: Magnetic Snap */
          @keyframes magnetic-snap {
            0% { letter-spacing: 0.5em; opacity: 0; }
            50% { opacity: 1; }
            80% { letter-spacing: -0.05em; } /* Snap together */
            100% { letter-spacing: normal; } /* Settle */
          }
          
          /* LOGO ANIMATION: Liquid Breathing Gradient */
          @keyframes liquid-flow {
            0% { background-position: 0% center; }
            100% { background-position: 200% center; }
          }

          .tribe-magnetic {
            display: inline-block;
            animation: magnetic-snap 1.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards;
          }

          .tribe-liquid {
            background: linear-gradient(90deg, #6F42C1 0%, #A78BFA 50%, #6F42C1 100%);
            background-size: 200% auto;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: liquid-flow 4s linear infinite;
          }

          /* CATEGORY ANIMATION: Pulse on Active */
          @keyframes icon-pulse {
            0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(111, 66, 193, 0.4); }
            70% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(111, 66, 193, 0); }
            100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(111, 66, 193, 0); }
          }
          
          .icon-active {
            animation: icon-pulse 0.5s ease-out;
          }

          /* CARD ANIMATION: Staggered Fade Up */
          @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }
          
          .card-enter {
            animation: fadeInUp 0.6s ease-out forwards;
            opacity: 0; 
          }
        `}
      </style>

      {/* HEADER */}
      <header className="px-5 py-3 md:px-8 md:py-6 flex justify-between items-center max-w-7xl mx-auto bg-white">
        {/* LOGO: Static 'my' + Magnetic 'tribe' */}
        <div className="text-xl md:text-2xl font-bold tracking-tight" style={{ fontWeight: 700 }}>
          <span className="text-[#222222]">my</span>
          <span className="tribe-magnetic tribe-liquid">tribe</span>
        </div>
        
        <div className="flex items-center gap-2 md:gap-4">
          <button className="flex items-center gap-1.5 px-3 py-1.5 md:px-4 md:py-2 bg-white rounded-full border border-gray-200 hover:border-gray-400 transition-colors">
            <MapPin className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#6F42C1]" />
            <span className="text-xs md:text-base text-gray-700 font-medium">Bengaluru</span>
            <ChevronDown className="w-3.5 h-3.5 md:w-4 md:h-4 text-gray-500" />
          </button>
          
          <button className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-[#6F42C1] flex items-center justify-center text-white hover:bg-[#5a3499] transition-colors shadow-sm">
            <User className="w-4 h-4 md:w-5 md:h-5" />
          </button>
        </div>
      </header>

      <section className="px-4 md:px-8 pt-8 md:pt-12 pb-20 bg-white">
        <div className="max-w-5xl mx-auto">
          {/* Hero Content */}
          <h1 
            className="text-center mb-10 md:mb-12 text-3xl md:text-5xl text-[#222222]" 
            style={{ 
              fontFamily: '"DM Sans", sans-serif', 
              fontWeight: 700,
              letterSpacing: '-0.03em',
              lineHeight: '1.1'
            }}
          >
            Find experts that match your vibe!
          </h1>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-10 md:mb-12 relative z-10">
            <div 
              className="flex items-center gap-2 p-1.5 pl-6 md:p-2 md:pl-8 bg-white border border-gray-100 transition-all duration-300 hover:shadow-2xl"
              style={{ 
                borderRadius: '100px',
                boxShadow: '0 16px 40px rgba(0, 0, 0, 0.12)' 
              }}
            >
              <input
                type="text"
                placeholder={placeholderText}
                className="flex-1 outline-none text-gray-900 placeholder:text-gray-500 bg-transparent text-sm md:text-base font-medium h-10 md:h-12 min-w-0"
                style={{ fontFamily: '"DM Sans", sans-serif' }}
              />
              <button 
                className="w-10 h-10 md:w-12 md:h-12 rounded-full flex-shrink-0 flex items-center justify-center text-white transition-transform hover:scale-105 active:scale-95"
                style={{
                  background: 'linear-gradient(135deg, #6F42C1 0%, #8b5cf6 100%)'
                }}
              >
                <Search className="w-4 h-4 md:w-5 md:h-5 font-bold" strokeWidth={2.5} />
              </button>
            </div>
          </div>

          {/* Category Navigation - New Mobile Swipe + Desktop Grid */}
          <div className="relative mb-8">
            
            {/* Desktop: Navigation Arrows (Hidden on Mobile) */}
            <button
              onClick={handlePrev}
              className="hidden md:flex absolute left-0 top-1/2 -translate-y-1/2 z-20 w-8 h-8 items-center justify-center bg-white rounded-full shadow-md border border-gray-200 text-gray-600 hover:scale-105 transition-all"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNext}
              className="hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 z-20 w-8 h-8 items-center justify-center bg-white rounded-full shadow-md border border-gray-200 text-gray-600 hover:scale-105 transition-all"
            >
              <ChevronRight className="w-5 h-5" />
            </button>

            {/* Container: Grid on Desktop, Flex Swipe on Mobile */}
            <div className="md:grid md:grid-cols-3 md:items-center md:max-w-lg md:mx-auto flex overflow-x-auto snap-x scrollbar-hide gap-8 px-4 md:gap-0">
              
              {categories.map((cat, index) => {
                const isActive = currentCategoryIndex === index;
                // Only show active logic for desktop grid placement, but show all in mobile list
                // To keep this code simple, we render the list for mobile and the 3-col grid for desktop separately?
                // Actually, let's keep the logic simple: Just map all categories for mobile.
                
                return (
                  <button
                    key={cat.id}
                    onClick={() => handleCategoryClick(index)}
                    className={`
                      flex flex-col items-center gap-2 cursor-pointer transition-all snap-center min-w-[80px]
                      ${isActive ? 'scale-110 icon-active' : 'opacity-60 hover:opacity-100 scale-90'}
                      /* Desktop specific positioning logic would be complex here, so strictly for this "Hero" vibe: */
                      /* We will hide non-active items on Desktop if following the "Prev/Next" pattern, OR just show simple list on mobile */
                    `}
                  >
                    <div className={`
                      w-14 h-14 rounded-full flex items-center justify-center transition-colors duration-300
                      ${isActive ? 'bg-white text-[#6F42C1] shadow-sm' : 'bg-[#F0F0F0] text-gray-500'}
                    `}>
                      {React.createElement(cat.icon, { size: 28, strokeWidth: isActive ? 2.5 : 2 })}
                    </div>
                    <span className={`text-xs md:text-sm font-medium ${isActive ? 'text-[#6F42C1] font-bold' : 'text-gray-500'}`}>
                      {cat.label}
                    </span>
                    {isActive && <div className="w-8 h-0.5 bg-[#6F42C1] rounded-full mt-1"></div>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sub-category Chips */}
          <div className="overflow-x-auto scrollbar-hide mt-6 md:mt-8 mb-8 -mx-8 px-8">
            <div className="flex gap-2 md:gap-3 w-max mx-auto px-4">
              {subCategories[activeCategory.id]?.map((sub) => (
                <button
                  key={sub}
                  onClick={() => handleSubCategoryClick(sub)}
                  className={`px-4 py-2 md:px-5 md:py-2.5 rounded-full transition-all flex items-center gap-2 whitespace-nowrap text-xs md:text-sm ${
                    selectedSubCategory === sub
                      ? 'bg-[#6F42C1] text-white shadow-md shadow-purple-200' 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200' 
                  }`}
                  style={{ fontWeight: 500 }}
                >
                  {sub}
                </button>
              ))}
            </div>
          </div>

          {/* --- TOP PICKS SECTION --- */}
          {selectedSubCategory && providersByCategory[selectedSubCategory] && (
            <div className="mt-8 transition-all duration-300 -mx-8 px-8 py-8 bg-white">
              
              {/* Header: "Top Picks For You" + "See All" */}
              <div className="flex items-center justify-between mb-6 px-2">
                <h3 className="text-xl md:text-2xl text-gray-900 font-bold">
                  Top Picks For You
                </h3>
                <button className="flex items-center gap-1 text-[#6F42C1] font-semibold text-sm hover:underline">
                  See All <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="overflow-x-auto scrollbar-hide -mx-4 md:-mx-8 px-4 md:px-8">
                <div className="flex gap-4 md:gap-6 pb-8">
                  {providersByCategory[selectedSubCategory].map((provider, index) => (
                    <div
                      key={provider.id}
                      /* Animation Stagger */
                      className="flex-shrink-0 w-[280px] md:w-[320px] cursor-pointer group card-enter"
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      {/* Image Container */}
                      <div className="aspect-[4/5] overflow-hidden rounded-2xl relative bg-gray-100 mb-4 shadow-sm group-hover:shadow-md transition-shadow">
                        
                        {/* Blurb Pill */}
                        <div className="absolute top-3 left-3 z-10 bg-white/95 backdrop-blur-sm px-3 py-1.5 rounded-2xl shadow-sm flex items-start gap-1.5 max-w-[85%]">
                          <div className="w-5 h-5 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                             <Sparkles className="w-3 h-3 text-[#6F42C1]" />
                          </div>
                          <span className="text-xs font-semibold text-gray-800 whitespace-normal leading-tight">
                            {provider.blurb}
                          </span>
                        </div>

                        {/* "See Images" Badge */}
                        <div className="absolute bottom-3 right-3 z-10 bg-black/40 backdrop-blur-md px-2 py-1 rounded-md flex items-center gap-1.5">
                          <ImageIcon className="w-3 h-3 text-white" />
                          <span className="text-[10px] font-bold text-white tracking-wide">+4</span>
                        </div>

                        <ImageWithFallback
                          src={provider.image}
                          alt={provider.name}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                        
                        {/* Hover Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      </div>
                      
                      {/* Card Content */}
                      <div className="flex flex-col gap-1.5 px-1">
                        <div className="flex justify-between items-start">
                          <h4 className="text-gray-900 font-bold text-lg leading-tight group-hover:text-[#6F42C1] transition-colors">
                            {provider.name}
                          </h4>
                        </div>
                        
                        <div className="flex items-center gap-1 text-gray-500">
                          <MapPin className="w-3.5 h-3.5" />
                          <p className="text-sm font-normal truncate">
                            {provider.location}
                          </p>
                        </div>
                        
                        <div className="mt-1 flex items-baseline gap-1">
                          <span className="text-gray-900 font-bold text-base">
                            ₹{provider.price}
                          </span>
                          <span className="text-gray-500 text-sm font-normal"> per session</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}