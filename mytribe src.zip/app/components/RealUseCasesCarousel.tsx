import React, { useRef, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, MapPin } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const useCases = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1646558583289-41e3c22a3e48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaXJ0aGRheSUyMHBhcnR5JTIwYmFsbG9vbnxlbnwxfHx8fDE3NjY5MTc3MDd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    provider: 'PartyPro Delhi',
    price: 2000,
    location: 'Delhi',
    description: 'Last minute balloon decor',
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1587271407850-8d438ca9fdf2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwZGVjb3JhdGlvbnxlbnwxfHx8fDE3NjY4ODg5Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    provider: 'Elegant Events',
    price: 25000,
    location: 'Mumbai',
    description: 'Premium wedding decoration',
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1537627856721-321efceec2a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJ0eSUyMG1hZ2ljaWFuJTIwcGVyZm9ybWVyfGVufDF8fHx8MTc2NjkxNzcwOHww&ixlib=rb-4.1.0&q=80&w=1080',
    provider: 'Magic Memories',
    price: 3500,
    location: 'Bangalore',
    description: 'Kids birthday magic show',
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1614607653708-0777e6d003b8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxldmVudCUyMHBob3RvZ3JhcGh5fGVufDF8fHx8MTc2NjkxNzcwOHww&ixlib=rb-4.1.0&q=80&w=1080',
    provider: 'FramePerfect Studio',
    price: 8000,
    location: 'Pune',
    description: 'Event photography package',
  },
  {
    id: 5,
    image: 'https://images.unsplash.com/photo-1732259495388-af40b972c311?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXRlcmluZyUyMGZvb2QlMjBzZXJ2aWNlfGVufDF8fHx8MTc2Njg1ODY2N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    provider: 'Tasty Bites Catering',
    price: 15000,
    location: 'Delhi',
    description: 'Premium buffet catering',
  },
  {
    id: 6,
    image: 'https://images.unsplash.com/photo-1698181842119-a5283dea1440?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWtldXAlMjBhcnRpc3QlMjBiZWF1dHl8ZW58MXx8fHwxNzY2OTE3NzA5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    provider: 'Glam Studio',
    price: 5500,
    location: 'Mumbai',
    description: 'Bridal makeup specialist',
  },
];

export function RealUseCasesCarousel() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [visibleCards, setVisibleCards] = useState<number[]>([]);
  const [priceRange, setPriceRange] = useState<'budget' | 'mid' | 'premium'>('budget');

  useEffect(() => {
    const handleScroll = () => {
      if (!scrollRef.current) return;

      const container = scrollRef.current;
      const containerRect = container.getBoundingClientRect();
      const cards = container.querySelectorAll('[data-card-id]');
      
      const visible: number[] = [];
      cards.forEach((card) => {
        const cardRect = card.getBoundingClientRect();
        const cardId = parseInt(card.getAttribute('data-card-id') || '0');
        
        // Check if card is visible in viewport
        if (
          cardRect.left < containerRect.right &&
          cardRect.right > containerRect.left
        ) {
          visible.push(cardId);
        }
      });

      setVisibleCards(visible);
      
      // Calculate price range based on visible cards
      if (visible.length > 0) {
        const visiblePrices = visible.map(id => useCases.find(uc => uc.id === id)?.price || 0);
        const avgPrice = visiblePrices.reduce((a, b) => a + b, 0) / visiblePrices.length;
        
        if (avgPrice < 5000) {
          setPriceRange('budget');
        } else if (avgPrice < 15000) {
          setPriceRange('mid');
        } else {
          setPriceRange('premium');
        }
      }
    };

    const container = scrollRef.current;
    if (container) {
      container.addEventListener('scroll', handleScroll);
      handleScroll(); // Initial check
    }

    return () => container?.removeEventListener('scroll', handleScroll);
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 400;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  const getPriceRangeText = () => {
    if (priceRange === 'budget') return 'Cost Effective';
    if (priceRange === 'mid') return 'Mid Range to Premium';
    return 'Premium';
  };

  return (
    <section className="py-20 px-8 bg-[#F7F7F7]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-12">
          <h2 className="text-2xl mb-3 text-[#111111]" style={{ fontWeight: 700 }}>
            Mytribe has it all!
          </h2>
          <p className="text-[#717171] text-xl transition-all duration-300" style={{ fontWeight: 400 }}>
            {getPriceRangeText()}
          </p>
        </div>

        {/* Carousel Container */}
        <div className="relative">
          <div
            ref={scrollRef}
            className="flex gap-6 overflow-x-auto scrollbar-hide scroll-smooth pb-4 pl-8 pr-16"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {useCases.map((useCase, index) => (
              <div
                key={useCase.id}
                data-card-id={useCase.id}
                className="flex-shrink-0 bg-white border border-[#E5E5E5] overflow-hidden hover:border-gray-300 transition-all cursor-pointer"
                style={{ 
                  borderRadius: '20px',
                  width: index === 0 ? '320px' : '320px',
                  boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.08), 0px 12px 24px rgba(0, 0, 0, 0.04)'
                }}
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <ImageWithFallback
                    src={useCase.image}
                    alt={useCase.description}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4 pb-16 relative">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[#111111]" style={{ fontWeight: 700 }}>{useCase.provider}</span>
                    <div className="flex items-center gap-1 text-[#717171] text-sm" style={{ fontWeight: 400 }}>
                      <MapPin className="w-3 h-3" />
                      <span>{useCase.location}</span>
                    </div>
                  </div>
                  <p className="text-[#717171] mb-2" style={{ fontWeight: 400 }}>{useCase.description}</p>
                  <div className="absolute bottom-4 right-4">
                    <span className="text-[#111111]" style={{ fontWeight: 700 }}>₹{useCase.price.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={() => scroll('left')}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-3 border border-[#E5E5E5] hover:border-gray-300 transition-all"
            style={{ boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.08), 0px 12px 24px rgba(0, 0, 0, 0.04)' }}
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <button
            onClick={() => scroll('right')}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-3 border border-[#E5E5E5] hover:border-gray-300 transition-all"
            style={{ boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.08), 0px 12px 24px rgba(0, 0, 0, 0.04)' }}
            aria-label="Scroll right"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
}