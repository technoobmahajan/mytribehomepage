import React from 'react';
import { Shield } from 'lucide-react';

export function TrustSection() {
  return (
    <section className="py-20 px-8 relative overflow-hidden" style={{ backgroundColor: '#F5F3FF' }}>
      {/* Subtle noise texture overlay */}
      <div 
        className="absolute inset-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      ></div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="flex flex-col items-center justify-center text-center">
          {/* Shield icon with gradient background */}
          <div 
            className="w-24 h-24 rounded-full flex items-center justify-center mb-6 relative overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, #6F42C1 0%, #8b5cf6 100%)'
            }}
          >
            <Shield className="w-12 h-12 text-white" strokeWidth={1.5} />
          </div>
          <h2 className="text-4xl text-[#111111]" style={{ fontWeight: 700 }}>
            Only 10% pass our verification
          </h2>
        </div>
      </div>
    </section>
  );
}